// src/plugins/vuetify.js
import 'vuetify/styles';  // Import Vuetify's default styles
import { createVuetify } from 'vuetify';  // Import Vuetify's core function
import * as components from 'vuetify/components';  // Import Vuetify components
import * as directives from 'vuetify/directives';  // Import Vuetify directives

// Create and export Vuetify instance
export default createVuetify({
  components,  // Register Vuetify components
  directives,  // Register Vuetify directives
});
