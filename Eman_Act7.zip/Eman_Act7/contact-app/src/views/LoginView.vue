<!-- src/views/LoginView.vue -->
<template>
    <v-container class="fill-height" fluid>
      <v-row align="center" justify="center">
        <v-col cols="12" sm="6" md="4">
          <v-card>
            <v-card-title>Login</v-card-title>
            <v-card-text>
              <v-text-field label="Username" v-model="username" />
            </v-card-text>
            <v-card-actions>
              <v-btn @click="login" color="primary" block>Login</v-btn>
            </v-card-actions>
          </v-card>
        </v-col>
      </v-row>
    </v-container>
  </template>
  
  <script setup>
  import { ref } from 'vue';
  import { useRouter } from 'vue-router';
  
  const username = ref('');
  const router = useRouter();
  
  const login = () => {
    if (username.value.trim() !== '') {
      localStorage.setItem('user', username.value);  // Store username in localStorage
      router.push('/dashboard');  // Redirect to dashboard
    } else {
      alert('Username is required!');
    }
  };
  </script>
  