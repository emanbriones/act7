<!-- src/views/DashboardView.vue -->
<template>
    <v-container>
      <v-row>
        <v-col>
          <v-toolbar color="indigo-darken-1" dark>
            <v-toolbar-title>Welcome, {{ username }}</v-toolbar-title>
            <v-spacer />
            <v-btn @click="logout" color="error">Logout</v-btn>
          </v-toolbar>
        </v-col>
      </v-row>
      <v-row>
        <v-col cols="12" md="6">
          <ContactForm @add-contact="addContact" />  <!-- Component to add contact -->
        </v-col>
      </v-row>
      <v-row>
        <v-col cols="12">
          <v-list>
            <v-list-item
              v-for="(contact, index) in contacts"
              :key="index"
              class="my-2"
            >
              <v-list-item-content>
                <v-list-item-title>{{ contact.name }}</v-list-item-title>
                <v-list-item-subtitle>{{ contact.phone }}</v-list-item-subtitle>
              </v-list-item-content>
              <v-list-item-action>
                <v-btn icon @click="deleteContact(index)">
                  <v-icon>mdi-delete</v-icon>
                </v-btn>
              </v-list-item-action>
            </v-list-item>
          </v-list>
        </v-col>
      </v-row>
    </v-container>
  </template>
  
  <script setup>
  import { ref, onMounted } from 'vue';
  import { useRouter } from 'vue-router';
  import ContactForm from '../components/ContactForm.vue';
  
  const contacts = ref([]);
  const username = ref('');
  const router = useRouter();
  
  onMounted(() => {
    const user = localStorage.getItem('user');
    if (!user) {
      router.push('/');  // Redirect to login if user is not logged in
    } else {
      username.value = user;
      const stored = JSON.parse(localStorage.getItem('contacts')) || [];
      contacts.value = stored;
    }
  });
  
  const addContact = (contact) => {
    contacts.value.push(contact);
    localStorage.setItem('contacts', JSON.stringify(contacts.value));  // Save contacts to localStorage
  };
  
  const deleteContact = (index) => {
    contacts.value.splice(index, 1);
    localStorage.setItem('contacts', JSON.stringify(contacts.value));  // Update localStorage
  };
  
  const logout = () => {
    localStorage.removeItem('user');  // Remove the user from localStorage
    router.push('/');  // Redirect to login
  };
  </script>
  