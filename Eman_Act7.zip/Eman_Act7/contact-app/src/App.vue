src/App.vue 
<template> 
 <router-view /> 
</template> 
<script setup> 
</script> 
