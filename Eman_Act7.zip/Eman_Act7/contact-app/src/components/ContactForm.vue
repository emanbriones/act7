<!-- src/components/ContactForm.vue -->
<template>
    <v-card>
      <v-card-title>Add Contact</v-card-title>
      <v-card-text>
        <v-form @submit.prevent="handleSubmit">
          <v-text-field v-model="name" label="Name" required />
          <v-text-field v-model="phone" label="Phone" required />
          <v-btn type="submit" color="primary" block>Add</v-btn>
        </v-form>
      </v-card-text>
    </v-card>
  </template>
  
  <script setup>
  import { ref } from 'vue';
  
  const name = ref('');
  const phone = ref('');
  const emit = defineEmits(['add-contact']);
  
  const handleSubmit = () => {
    if (name.value && phone.value) {
      emit('add-contact', { name: name.value, phone: phone.value });  // Emit event to parent
      name.value = '';  // Clear the input fields
      phone.value = '';
    }
  };
  </script>
  